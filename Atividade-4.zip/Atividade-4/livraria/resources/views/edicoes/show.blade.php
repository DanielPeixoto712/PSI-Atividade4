<ul>
@foreach($edicoes as $edicao)
<li>{{$edicao->id_edidora}}</li>
@endforeach
</ul>
{{$edicoes->render()}}