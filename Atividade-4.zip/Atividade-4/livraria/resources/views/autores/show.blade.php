ID:{{$edicoes->id_autor}}<br>
Editora:{{$edicoes->id_editora}}<br>
Data:{{$edicoes->data}}